const express = require("express");
const router = express.Router();
const { getProducts, createProduct } = require("../../controllers/productController");
const { protect } = require("../../middleware/authMiddleware");

// @desc    Get all products
// @route   GET /api/products
// @access  Public
router.get("/", getProducts);

// @desc    Create a new product
// @route   POST /api/products
// @access  Private (logged-in users only)
router.post("/", protect, createProduct);

module.exports = router;
