const express = require("express");
const router = express.Router();
const Contact = require("../../models/contactModel");

// POST message from contact form
router.post("/", async (req, res) => {
  try {
    const newMsg = await Contact.create(req.body);
    res.json({ success: true, message: "Message received!" });
  } catch (err) {
    res.status(500).json({ success: false, message: "Error saving message" });
  }
});

module.exports = router;
