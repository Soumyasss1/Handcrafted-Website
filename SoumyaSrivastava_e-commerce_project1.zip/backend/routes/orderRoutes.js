const express = require("express");
const router = express.Router();
const Order = require("../models/orderModel");

router.post("/", async (req, res) => {
  const order = await Order.create(req.body);
  res.json(order);
});

module.exports = router;
